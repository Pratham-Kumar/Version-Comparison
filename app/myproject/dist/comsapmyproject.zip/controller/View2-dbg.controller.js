sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
function (Controller, MessageBox) {
    "use strict";

    return Controller.extend("com.sap.myproject.controller.View2", {
        onInit: function () {

        },
    });
});
